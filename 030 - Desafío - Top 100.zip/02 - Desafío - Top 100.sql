--1. Crear base de datos llamada películas/reparto.
CREATE DATABASE peliculas
    WITH 
    OWNER = postgres
    ENCODING = 'UTF8'
    CONNECTION LIMIT = -1;
	
--2. Cargar ambos archivos a su tabla correspondiente.
CREATE TABLE peliculas(
    id INT,
    Pelicula VARCHAR(255),
    anio_estreno VARCHAR(4),
    Director VARCHAR (255),
    PRIMARY KEY(id)
);

CREATE TABLE reparto (
    id_pelicula INT, 
    Actor VARCHAR(255), 
FOREIGN KEY (id_pelicula) REFERENCES peliculas (id)
);

SELECT * FROM reparto

SELECT * FROM peliculas


--3. Obtener el ID de la película “Titanic”.
SELECT id FROM peliculas
WHERE Pelicula LIKE 'Titanic'


--4. Listar a todos los actores que aparecen en la película "Titanic".
SELECT * FROM reparto
WHERE id_pelicula=2


--5. Consultar en cuántas películas del top 100 participa Harrison Ford.
SELECT COUNT (id_pelicula) FROM reparto
WHERE Actor LIKE 'Harrison Ford'

 
--6. Indicar las películas estrenadas entre los años 1990 y 1999 
--ordenadas por título de manera ascendente.
SELECT * FROM peliculas
WHERE anio_estreno BETWEEN '1990' AND '1999'
ORDER BY Pelicula ASC 

 

--7. Hacer una consulta SQL que muestre los títulos con su longitud, 
--la longitud debe ser nombrado para la consulta como “longitud_titulo”.
SELECT Pelicula, 
LENGTH (Pelicula) 
AS longitud_titulo
FROM peliculas

 
--8. Consultar cual es la longitud más grande entre todos los títulos de las películas.
SELECT MAX(LENGTH(Pelicula)) 
AS longitud_titulo
FROM peliculas


--8. Consultar cual es la palícula con la longitud más grande de caracteres entre todos los títulos de las películas.
SELECT Pelicula, 
LENGTH (Pelicula) 
AS longitud_titulo
FROM peliculas
ORDER BY LENGTH(Pelicula) DESC
LIMIT 1