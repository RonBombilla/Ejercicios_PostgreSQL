-- 1. Cargar el respaldo de la base de datos
-- 2. Compra cliente usuario01
BEGIN TRANSACTION;
INSERT INTO compra(cliente_id, fecha) VALUES(1, now());
INSERT INTO detalle_compra(producto_id,compra_id, cantidad)
VALUES(9, (SELECT MAX(id) FROM compra), 5);
UPDATE producto AS prod SET stock = stock - 5 WHERE id = 9;
COMMIT;
SELECT * FROM producto WHERE id = 9;

-- 3. Compra cliente usuario02
BEGIN TRANSACTION;
INSERT INTO compra(cliente_id, fecha) VALUES(2, now());
INSERT INTO detalle_compra(producto_id,compra_id, cantidad)
VALUES(1, (SELECT MAX(id) FROM compra), 3);
UPDATE producto AS prod SET stock = stock - 3 WHERE id = 1;
INSERT INTO detalle_compra(producto_id,compra_id, cantidad)
VALUES(2, (SELECT MAX(id) FROM compra), 3);
UPDATE producto AS prod SET stock = stock - 3 WHERE id = 2;
INSERT INTO detalle_compra(producto_id,compra_id, cantidad)
VALUES(8, (SELECT MAX(id) FROM compra), 3);
UPDATE producto AS prod SET stock = stock - 3 WHERE id = 8;
COMMIT;
SELECT * FROM producto WHERE id IN (1, 2, 8);

-- 4. Realizar las consultas
-- a. \set AUTOCOMMIT off
-- b. insertar un nuevo client
-- BEGIN TRANSACTION -- (en caso de ser transaction)
INSERT INTO cliente (nombre, email) VALUES('usuario011', 'usuario011@hotmail.com');
-- c. Confirmar que fue agregado
SELECT * FROM cliente WHERE nombre = 'usuario011';
-- d. Realizar rollback
ROLLBACK;
-- e. confirmación de restauración de la información
SELECT * FROM cliente WHERE nombre = 'usuario011';
-- f. \set AUTOCOMMIT off;