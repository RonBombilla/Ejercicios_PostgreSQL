-- 1. Crear base de datos

-- 2. Crear las tablas
CREATE TABLE usuario (
id SERIAL PRIMARY KEY,
email VARCHAR(40) NOT NULL UNIQUE
);



CREATE TABLE post (
id SERIAL PRIMARY KEY,
usuario_id INTEGER NOT NULL REFERENCES usuario(id),
titulo VARCHAR(100) NOT NULL UNIQUE,
fecha DATE
);



CREATE TABLE comentario (
id SERIAL PRIMARY KEY,
post_id INTEGER NOT NULL REFERENCES post(id),
usuario_id INTEGER NOT NULL REFERENCES usuario(id),
texto VARCHAR(500) NOT NULL,
fecha DATE
);



-- 3. "Insert de los registros", importados de archivo csv
-- 4. post publicados por el usuario 5
SELECT *
FROM public.usuario AS usuario
JOIN public.post AS post
ON usuario.id = post.usuario_id
WHERE usuario.id = 5;



-- 5 listar los comentarios del usuario 6
SELECT *
FROM public.usuario AS usuario
JOIN public.comentario AS comentario
ON usuario.id = comentario.usuario_id
WHERE usuario.email != 'usuario06@hotmail.com';



-- 6. Listar los usuarios que no han realizado ningun post
SELECT *
FROM public.usuario AS usuario
LEFT JOIN public.post AS post
ON usuario.id = post.usuario_id
WHERE post.id IS NULL;



-- 7. listar post con sus comentarios
SELECT *
FROM public.post AS post
FULL OUTER JOIN public.comentario AS comentario
ON post.id = comentario.post_id



-- 8. Listar todos los usuarios que hayan publicado en junio
SELECT *
FROM public.usuario AS usuario
INNER JOIN public.post AS post
ON usuario.id = post.usuario_id
WHERE post.fecha BETWEEN '2020-06-01' AND '2020-06-30'