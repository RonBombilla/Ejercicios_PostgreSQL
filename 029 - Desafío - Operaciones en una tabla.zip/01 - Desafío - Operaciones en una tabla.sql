--Parte 1---------------------------------------------------------

--Creación de una base de datos llamada Posts
CREATE DATABASE Posts;

 

--Creación de una tabla post
CREATE TABLE post(id INT,nombre_de_usuario VARCHAR(25),fecha_de_creación DATE,
contenido VARCHAR(50),descripción VARCHAR(50),PRIMARY KEY(id));

 

--Insertar 3 post, 2 para el usuario "Pamela" y uno para "Carlos".
INSERT INTO public.post(id,nombre_de_usuario,fecha_de_creación,
contenido,descripción)
VALUES (1,'Pamela','2020-03-05','Lorem ipsum dolor sit amet consectetur','velit qui ipsum incidunt amet'),
(2,'Pamela','2019-04-03','iure architecto placeat',
'adipisicing elit. Repellat'),
(3,'Carlos','2015-07-08','iure architecto officiis rem possimus',
'adipisicing elit. Repellat');

 

--Modificar la tabla post agregando la columna titulo.
ALTER TABLE public.post ADD COLUMN titulo VARCHAR(25);

 

--Agregar los datos a la columna título a las publicaciones ya ingresada
UPDATE public.post
SET titulo='Hola Compañeros'
WHERE id>=1;

 

--Agregar dos insert para el usuario Pedro
INSERT INTO public.post(id,nombre_de_usuario,fecha_de_creación,
contenido,descripción,titulo)
VALUES (1,'Pedro','2020-03-05','Lorem ipsum dolor sit amet consectetur','velit qui ipsum incidunt amet','Chao Compañero'),
(2,'Pedro','2019-04-03','iure architecto placeat',
'adipisicing elit. Repellat','Chao Compañero');

 

--Eliminar el post de Carlos
DELETE FROM public.post
WHERE nombre_de_usuario='Carlos';

 

--Ingresar un nuevo post para Carlos
INSERT INTO public.post(id,nombre_de_usuario,fecha_de_creación,
contenido,descripción,titulo)
VALUES (1,'Carlos','2018-09-02','Lorem ipsum dolor sit amet consectetur','velit qui ipsum incidunt amet','Hola de Nuevo');


SELECT * FROM post;






/*PARTE 2*/

--Crear tabla comentarios y asociar llave
CREATE TABLE comentarios(id INT,fecha DATE, hora_de_creacion TIME,
contenido VARCHAR(50), FOREIGN KEY(id) REFERENCES post(id));


--Ingresar un nuevo registro en la tabla comentarios para Carlos y Pamela 
INSERT INTO public.comentarios(id,fecha,hora_de_creacion,
contenido)
VALUES (1,'2018-02-10','11:37:10','Lorem ipsum dolor sit amet consectetur'),
(2,'2018-03-10','12:37:10','Lorem ipsum dolor sit amet consectetur'),
(6,'2018-04-10','13:37:10','Lorem ipsum dolor sit amet consectetur'),
(6,'2018-05-10','14:37:10','Lorem ipsum dolor sit amet consectetur'),
(6,'2018-06-10','15:37:10','Lorem ipsum dolor sit amet consectetur'),
(6,'2018-07-10','16:37:10','Lorem ipsum dolor sit amet consectetur');


--Insertar un nuevo post para Margarita
INSERT INTO public.post(id,nombre_de_usuario,fecha_de_creación,
contenido,descripción,titulo)
VALUES (7,'Margarita','2021-09-02','Lorem ipsum dolor sit amet consectetur','velit qui ipsum incidunt amet','Hola de Nuevo');


--Ingresar 5 nuevos comentarios para el post de Margarita
INSERT INTO public.comentarios(id,fecha,hora_de_creacion,contenido) 
VALUES (7,'2018-01-02','2:54:26','Lorem ipsum dolor sit amet consectetur'),
(7,'2018-02-02','3:54:26','Lorem ipsum dolor sit amet consectetur'),
(7,'2018-03-02','4:54:26','Lorem ipsum dolor sit amet consectetur'),
(7,'2018-04-02','5:54:26','Lorem ipsum dolor sit amet consectetur'),
(7,'2018-05-02','6:54:26','Lorem ipsum dolor sit amet consectetur');

SELECT * FROM comentarios;